var numero = Math.random();

if (numero <= 0.5)
{
  console.log('\n' + numero + 'MENOR que 0.5 \n');
}else
{
  console.log('\n' + numero + 'MAYOR que 0.5 \n');
}
console.log('\n' + numero + str '\n');
