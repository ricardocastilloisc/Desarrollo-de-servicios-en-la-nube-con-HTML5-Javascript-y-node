Es un programa que hace un número random y comprueba si es mayor o menor que 5
